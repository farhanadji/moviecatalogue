package picodiploma.dicoding.submission5;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.Objects;

import androidx.core.content.ContextCompat;
import picodiploma.dicoding.submission5.api.clientAPI;
import picodiploma.dicoding.submission5.database.FavoriteHelper;
import picodiploma.dicoding.submission5.detail.MovieItem;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailMovie extends AppCompatActivity {
    public static String movieID;
    public String TAG = "detail movie";
    clientAPI APIClient = null;
    private int mov_id;
    private Call<MovieItem> callDetail;
    private String IMG_URL = "https://image.tmdb.org/t/p/";
    private MovieItem detailMovie;
    private FavoriteHelper favoriteHelper;
    private MovieItem favorite;
    private boolean setFavorite = false;
    private final AppCompatActivity activity = DetailMovie.this;
    private final static String API_KEY = BuildConfig.API_KEY;
    String titleToast = "title";
    ImageView backdrop;
    ImageView postermovie;
    TextView titleMovie;
    TextView description;
    TextView ReleaseDate;
    Menu menu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_movie);

        backdrop = findViewById(R.id.iv_backdrop);
        postermovie = findViewById(R.id.iv_poster);
        titleMovie = findViewById(R.id.tv_titleMovie);
        ReleaseDate = findViewById(R.id.year);
        description = findViewById(R.id.tv_desc);


        mov_id = getIntent().getIntExtra(movieID, mov_id);
        Log.d(TAG, "Received Id :" + mov_id);
        APIClient = clientAPI.getInstance();
        callDetail = APIClient.getApi().getDetailMovie(mov_id, API_KEY);
        callDetail.enqueue(new Callback<MovieItem>() {
            @Override
            public void onResponse(Call<MovieItem> call, Response<MovieItem> response) {
                if (response.isSuccessful()) {
                    detailMovie = response.body();
                    String poster_path = IMG_URL + "w342" + detailMovie.getPosterPath();
                    String backdrop_path = IMG_URL + "original" + detailMovie.getBackdropPath();

                    titleToast = detailMovie.getTitle();
                    Objects.requireNonNull(getSupportActionBar()).setTitle(detailMovie.getTitle());
                    titleMovie.setText(detailMovie.getTitle());
                    ReleaseDate.setText(detailMovie.getRelease_date());
                    description.setText(detailMovie.getOverview());
                    Picasso.get().load(poster_path).into(postermovie);
                    Picasso.get().load(backdrop_path).fit().into(backdrop);

                } else {
                    Log.d(TAG, "fail");
                }
            }

            @Override
            public void onFailure(Call<MovieItem> call, Throwable t) {

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        this.menu = menu;
        getMenuInflater().inflate(R.menu.favorite,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        if(item.getItemId() == R.id.fav_button){

            saveFavorite();
        }
        return super.onOptionsItemSelected(item);
    }

    public void saveFavorite(){
        favoriteHelper = new FavoriteHelper(activity);
        favorite = new MovieItem();
        if(favoriteHelper.checkId(mov_id)){
            setFavorite = false;
            favoriteHelper.open();
            favoriteHelper.deleteMovie(mov_id);
            Toast.makeText(activity, titleToast+ " " + getString(R.string.toast_fav_remove), Toast.LENGTH_LONG).show();
        }else {
            setFavorite = true;
            favorite.setMovie_id(mov_id);
            favorite.setRelease_date(detailMovie.getRelease_date());
            favorite.setOverview(detailMovie.getOverview());
            favorite.setPosterPath(detailMovie.getPosterPath());
            favorite.setBackdropPath(detailMovie.getBackdropPath());
            favorite.setTitle(detailMovie.getTitle());

            favoriteHelper.open();
            favoriteHelper.insertMovie(favorite);
            Toast.makeText(activity, titleToast+ " " + getString(R.string.toast_fav_add), Toast.LENGTH_SHORT).show();

        }
        setFavoriteIconState();
    }


    public void checkFavorite(){

    }

    private void setFavoriteIconState() {
        if(setFavorite) {
            menu.getItem(0).setIcon(ContextCompat.getDrawable(this, R.drawable.fav_button_clicked));
        } else {
            menu.getItem(0).setIcon(ContextCompat.getDrawable(this, R.drawable.fav_button));
        }
    }

}
